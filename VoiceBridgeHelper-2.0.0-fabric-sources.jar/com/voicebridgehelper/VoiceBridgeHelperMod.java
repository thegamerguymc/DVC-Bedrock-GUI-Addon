package com.voicebridgehelper;

import com.mojang.brigadier.context.CommandContext;
import de.maxhenkel.voicechat.api.Group;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.VoicechatServerStartedEvent;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;
import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.cumulus.form.util.FormBuilder;
import org.geysermc.floodgate.api.FloodgateApi;
import org.geysermc.floodgate.api.player.FloodgatePlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class VoiceBridgeHelperMod implements ModInitializer, VoicechatPlugin {

    private static final Logger LOGGER = LoggerFactory.getLogger("voicebridgehelper");
    private static final Duration BEDROCK_INVITE_EXPIRATION = Duration.ofSeconds(60L);
    private static final String MOD_ID = "voicebridgehelper";
    private static final String VC_MENU_MARKER = "voicebridgehelper_vc_menu";
    private static volatile VoicechatServerApi SHARED_VOICECHAT_SERVER_API;

    private enum MenuAccessMode {
        COMMAND,
        BOTH,
        NETHER_STAR
    }

    private enum MenuState {
        NONE,
        MAIN,
        HELP,
        GROUP_LIST,
        JOIN_GROUP,
        JOIN_PASSWORD,
        CREATE_GROUP
    }

    private record ScheduledTask(long runAtTick, long id, Runnable action) {
    }

    private record BedrockGroupInvite(UUID inviterId, String inviterName, UUID groupId, Instant createdAt) {
        private boolean isExpired() {
            return Instant.now().isAfter(createdAt.plus(BEDROCK_INVITE_EXPIRATION));
        }
    }

    private final Map<UUID, String> groupPasswords = new ConcurrentHashMap<>();
    private final Map<UUID, MenuState> menuStates = new ConcurrentHashMap<>();
    private final Map<UUID, String> joinMenuSignatures = new ConcurrentHashMap<>();
    private final Map<UUID, Instant> dvcCooldown = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> lastKnownGroupByPlayer = new ConcurrentHashMap<>();
    private final Map<UUID, BedrockGroupInvite> pendingBedrockInvites = new ConcurrentHashMap<>();
    private final Map<UUID, Long> joinMenuRefreshTokens = new ConcurrentHashMap<>();
    private final List<ScheduledTask> scheduledTasks = new ArrayList<>();

    private MinecraftServer server;
    private Duration dvcStartCooldown = Duration.ofSeconds(15L);
    private long joinMenuRefreshTicks = 60L;
    private MenuAccessMode menuAccessMode = MenuAccessMode.COMMAND;
    private long currentTick;
    private long nextTaskId;

    @Override
    public void onInitialize() {
        loadConfig();

        ServerLifecycleEvents.SERVER_STARTED.register(startedServer -> this.server = startedServer);
        ServerLifecycleEvents.SERVER_STOPPING.register(stoppingServer -> {
            this.server = stoppingServer;
            SHARED_VOICECHAT_SERVER_API = null;
            synchronized (scheduledTasks) {
                scheduledTasks.clear();
            }
            joinMenuRefreshTokens.clear();
            menuStates.clear();
            joinMenuSignatures.clear();
            pendingBedrockInvites.clear();
        });

        ServerTickEvents.END_SERVER_TICK.register(tickServer -> {
            this.server = tickServer;
            currentTick++;
            runDueTasks();
            if (usesNetherStarAccess()) {
                for (class_3222 player : tickServer.method_3760().method_14571()) {
                    if (isBedrockPlayer(player)) {
                        sanitizeMenuItemState(player);
                    }
                }
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, tickServer) -> onPlayerQuit(handler.method_32311()));
        ServerPlayConnectionEvents.JOIN.register((handler, tickServer, sender) ->
                scheduleLater(20L, () -> syncBedrockState(handler.method_32311()))
        );
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof class_1542 itemEntity && isVcMenuItem(itemEntity.method_6983())) {
                itemEntity.method_31472();
            }
            if (entity instanceof class_1533 itemFrame && isVcMenuItem(itemFrame.method_6940())) {
                itemFrame.method_6933(class_1799.field_8037, false);
            }
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) ->
                scheduleLater(20L, () -> {
                    syncBedrockState(newPlayer);
                })
        );
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.method_8608() || !(player instanceof class_3222 serverPlayer)) {
                return class_1269.field_5811;
            }
            if (!isBedrockPlayer(serverPlayer) || !usesNetherStarAccess() || !isVcMenuItem(serverPlayer.method_5998(hand))) {
                return class_1269.field_5811;
            }
            showMainMenu(serverPlayer);
            return class_1269.field_5812;
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608() || !(player instanceof class_3222 serverPlayer)) {
                return class_1269.field_5811;
            }
            if (!isBedrockPlayer(serverPlayer) || !isVcMenuItem(serverPlayer.method_5998(hand))) {
                return class_1269.field_5811;
            }
            if (entity instanceof class_1533) {
                return class_1269.field_5814;
            }
            return class_1269.field_5811;
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    class_2170.method_9247("bvc")
                            .executes(this::openBedrockMenu)
                            .then(class_2170.method_9247("invite")
                                    .then(class_2170.method_9244("player", class_2186.method_9305())
                                            .executes(this::invitePlayer)))
            );
            dispatcher.register(
                    class_2170.method_9247("dvcui")
                            .executes(this::openBedrockMenu)
                            .then(class_2170.method_9247("invite")
                                    .then(class_2170.method_9244("player", class_2186.method_9305())
                                            .executes(this::invitePlayer)))
            );
        });
    }

    @Override
    public String getPluginId() {
        return MOD_ID;
    }

    @Override
    public void initialize(de.maxhenkel.voicechat.api.VoicechatApi api) {
        if (api instanceof VoicechatServerApi serverApi) {
            SHARED_VOICECHAT_SERVER_API = serverApi;
            LOGGER.info("Simple Voice Chat API initialized for VoiceBridgeHelper.");
        }
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(VoicechatServerStartedEvent.class, event -> {
            SHARED_VOICECHAT_SERVER_API = event.getVoicechat();
            LOGGER.info("Simple Voice Chat server API is ready.");
        });
    }

    private int openBedrockMenu(CommandContext<class_2168> context) {
        class_3222 player;
        try {
            player = context.getSource().method_9207();
        } catch (Exception exception) {
            context.getSource().method_9213(class_2561.method_43470("Only players can use this command."));
            return 0;
        }

        if (!isBedrockPlayer(player)) {
            player.method_64398(class_2561.method_43470("This menu is Bedrock-only. Use /dvc directly on Java."));
            return 0;
        }

        showMainMenu(player);
        return 1;
    }

    private int invitePlayer(CommandContext<class_2168> context) {
        class_3222 inviter;
        try {
            inviter = context.getSource().method_9207();
        } catch (Exception exception) {
            context.getSource().method_9213(class_2561.method_43470("Only players can use this command."));
            return 0;
        }

        class_3222 target;
        try {
            target = class_2186.method_9315(context, "player");
        } catch (Exception exception) {
            context.getSource().method_9213(class_2561.method_43470("That player could not be resolved."));
            return 0;
        }
        if (!isBedrockPlayer(target)) {
            inviter.method_64398(class_2561.method_43470("That player is not a Bedrock player."));
            return 0;
        }

        handleBedrockVoicechatInvite(inviter, target);
        return 1;
    }

    private void showMainMenu(class_3222 player) {
        cancelJoinMenuRefresh(player.method_5667());
        setMenuState(player.method_5667(), MenuState.MAIN);

        SimpleForm.Builder form = SimpleForm.builder()
                .title("VoiceBridgeHelper")
                .content("Control Discord VC without typing commands")
                .button("Join Discord VC (/dvc start)")
                .button("List Groups")
                .button("Join Group")
                .button("Create Group")
                .button("Leave Group")
                .button("Group Info")
                .button("Help")
                .validResultHandler(response -> {
                    int button = response.clickedButtonId();
                    if (button == 0) {
                        maybeRunDvcStart(player);
                        sendDiscordVoiceReminder(player);
                        showMainMenu(player);
                        return;
                    }
                    if (button == 1) {
                        showGroupListMenu(player);
                        return;
                    }
                    if (button == 2) {
                        showJoinGroupMenu(player);
                        return;
                    }
                    if (button == 3) {
                        showCreateGroupForm(player);
                        return;
                    }
                    if (button == 4) {
                        leaveGroup(player, true);
                        return;
                    }
                    if (button == 5) {
                        showGroupInfo(player);
                        showMainMenu(player);
                        return;
                    }
                    if (button == 6) {
                        showHelpMenu(player);
                        return;
                    }
                    showMainMenu(player);
                })
                .closedOrInvalidResultHandler(() -> dismissMenu(player));

        sendToBedrock(player, form);
    }

    private void showHelpMenu(class_3222 player) {
        cancelJoinMenuRefresh(player.method_5667());
        setMenuState(player.method_5667(), MenuState.HELP);

        SimpleForm.Builder form = SimpleForm.builder()
                .title("VoiceBridgeHelper Help")
                .content(
                        "How to use:\n" +
                        "- Run /bvc to open this menu.\n" +
                        "- Tap 'Join Discord VC' to run /dvc start.\n" +
                        "- Use 'Create Group' or 'Join Group' to enter a voice group.\n" +
                        "- If a group is locked, enter the password.\n" +
                        "- Use 'Leave Group' when done.\n\n" +
                        "Tips:\n" +
                        "- /dvc start auto-runs when you create or join a group.\n" +
                        "- Use /bvc invite <player> to invite a Bedrock player to your group.\n" +
                        "- If Discord voice does not connect, press Join Discord VC again."
                )
                .button("Back")
                .validResultHandler(response -> showMainMenu(player))
                .closedOrInvalidResultHandler(() -> dismissMenu(player));

        sendToBedrock(player, form);
    }

    private void showGroupListMenu(class_3222 player) {
        cancelJoinMenuRefresh(player.method_5667());
        setMenuState(player.method_5667(), MenuState.GROUP_LIST);

        VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
        if (voicechatServerApi == null) {
            player.method_64398(class_2561.method_43470("Voice chat API is not ready yet."));
            showMainMenu(player);
            return;
        }

        List<Group> groups = getSortedGroups();
        SimpleForm.Builder form = SimpleForm.builder()
                .title("Available Groups")
                .content(groups.isEmpty() ? "No groups found." : "Current voice groups")
                .button("Back");

        for (Group group : groups) {
            form.button(group.getName() + " [" + groupTypeLabel(group.getType()) + "] id=" + group.getId());
        }

        form.validResultHandler(response -> showMainMenu(player))
                .closedOrInvalidResultHandler(() -> dismissMenu(player));

        sendToBedrock(player, form);
    }

    private void showJoinGroupMenu(class_3222 player) {
        VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
        if (voicechatServerApi == null) {
            player.method_64398(class_2561.method_43470("Voice chat API is not ready yet."));
            showMainMenu(player);
            return;
        }

        VoicechatConnection connection = getConnection(player);
        if (connection == null) {
            player.method_64398(class_2561.method_43470("Voice chat connection is unavailable."));
            return;
        }

        List<Group> visibleGroups = getSortedGroups();
        UUID playerId = player.method_5667();
        setMenuState(playerId, MenuState.JOIN_GROUP);
        joinMenuSignatures.put(playerId, createJoinMenuSignature(visibleGroups));

        SimpleForm.Builder form = SimpleForm.builder()
                .title("Join Group")
                .content(visibleGroups.isEmpty() ? "No groups available." : "Select a group to join")
                .button("Refresh");

        for (Group group : visibleGroups) {
            String lock = group.hasPassword() ? " [LOCKED]" : "";
            form.button(group.getName() + " (" + groupTypeLabel(group.getType()) + ")" + lock);
        }

        form.validResultHandler(response -> {
                    int clicked = response.clickedButtonId();
                    if (clicked == 0) {
                        showJoinGroupMenu(player);
                        return;
                    }
                    int groupIndex = clicked - 1;
                    if (groupIndex < 0 || groupIndex >= visibleGroups.size()) {
                        showJoinGroupMenu(player);
                        return;
                    }
                    Group selected = visibleGroups.get(groupIndex);
                    if (selected.hasPassword()) {
                        showJoinPasswordForm(player, selected);
                    } else {
                        joinGroup(player, selected, null);
                    }
                })
                .closedOrInvalidResultHandler(() -> {
                    cancelJoinMenuRefresh(playerId);
                    setMenuState(playerId, MenuState.NONE);
                });

        sendToBedrock(player, form);
        scheduleJoinMenuRefresh(player);
    }

    private void showJoinPasswordForm(class_3222 player, Group group) {
        cancelJoinMenuRefresh(player.method_5667());
        setMenuState(player.method_5667(), MenuState.JOIN_PASSWORD);

        CustomForm.Builder form = CustomForm.builder()
                .title("Password Required")
                .input("Password", "Enter group password", "")
                .validResultHandler(response -> joinGroup(player, group, response.asInput(0)))
                .closedOrInvalidResultHandler(() -> dismissMenu(player));

        sendToBedrock(player, form);
    }

    private void joinGroup(class_3222 player, Group group, String suppliedPassword) {
        joinGroup(player, group, suppliedPassword, false, true);
    }

    private void joinGroup(class_3222 player, Group group, String suppliedPassword, boolean bypassPassword, boolean showMenuAfterJoin) {
        VoicechatConnection connection = getConnection(player);
        if (connection == null) {
            player.method_64398(class_2561.method_43470("Voice chat connection is unavailable."));
            return;
        }

        if (connection.getGroup() != null && Objects.equals(connection.getGroup().getId(), group.getId())) {
            player.method_64398(class_2561.method_43470("You are already in that group."));
            if (showMenuAfterJoin) {
                showMainMenu(player);
            }
            return;
        }

        if (group.hasPassword() && !bypassPassword) {
            String expected = groupPasswords.get(group.getId());
            if (expected != null && !expected.equals(suppliedPassword)) {
                player.method_64398(class_2561.method_43470("Invalid group password."));
                showJoinPasswordForm(player, group);
                return;
            }
        }

        connection.setGroup(group);
        lastKnownGroupByPlayer.put(player.method_5667(), group.getId());
        player.method_64398(class_2561.method_43470("Joined group: " + group.getName()));
        ensureDiscordVoiceStartedForGroupJoin(player);

        if (showMenuAfterJoin) {
            showMainMenu(player);
        }
    }

    private void showCreateGroupForm(class_3222 player) {
        cancelJoinMenuRefresh(player.method_5667());
        setMenuState(player.method_5667(), MenuState.CREATE_GROUP);

        VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
        if (voicechatServerApi == null) {
            player.method_64398(class_2561.method_43470("Voice chat API is not ready yet."));
            showMainMenu(player);
            return;
        }

        CustomForm.Builder form = CustomForm.builder()
                .title("Create Group")
                .input("Name", "Group name", "")
                .dropdown("Type", List.of("OPEN", "NORMAL", "ISOLATED"), 1)
                .input("Password (optional)", "Leave empty for none", "")
                .toggle("Persistent Group", false)
                .validResultHandler(response -> {
                    String name = response.asInput(0);
                    int typeIndex = response.asDropdown(1);
                    String password = response.asInput(2);
                    boolean persistent = response.asToggle(3);

                    if (name == null || name.isBlank()) {
                        player.method_64398(class_2561.method_43470("Group name cannot be empty."));
                        showCreateGroupForm(player);
                        return;
                    }

                    String typeRaw = switch (typeIndex) {
                        case 0 -> "OPEN";
                        case 1 -> "NORMAL";
                        case 2 -> "ISOLATED";
                        default -> "NORMAL";
                    };

                    String normalizedPassword = normalizePassword(password);
                    Group created;
                    try {
                        created = voicechatServerApi.groupBuilder()
                                .setName(name)
                                .setPersistent(persistent)
                                .setPassword(normalizedPassword)
                                .setType(resolveGroupType(typeRaw))
                                .build();
                    } catch (RuntimeException exception) {
                        LOGGER.warn("Failed to create voice chat group", exception);
                        player.method_64398(class_2561.method_43470("Could not create the group. Check the server log."));
                        showCreateGroupForm(player);
                        return;
                    }

                    if (normalizedPassword != null) {
                        groupPasswords.put(created.getId(), normalizedPassword);
                    } else {
                        groupPasswords.remove(created.getId());
                    }

                    VoicechatConnection connection = getConnection(player);
                    if (connection != null) {
                        connection.setGroup(created);
                        lastKnownGroupByPlayer.put(player.method_5667(), created.getId());
                        player.method_64398(class_2561.method_43470("Created and joined group: " + created.getName()));
                        ensureDiscordVoiceStartedForGroupJoin(player);
                    }

                    showMainMenu(player);
                })
                .closedOrInvalidResultHandler(() -> dismissMenu(player));

        sendToBedrock(player, form);
    }

    private void leaveGroup(class_3222 player, boolean returnToMain) {
        VoicechatConnection connection = getConnection(player);
        if (connection == null) {
            player.method_64398(class_2561.method_43470("Voice chat connection is unavailable."));
            if (returnToMain) {
                showMainMenu(player);
            }
            return;
        }

        Group oldGroup = connection.getGroup();
        connection.setGroup(null);
        lastKnownGroupByPlayer.remove(player.method_5667());

        if (oldGroup == null) {
            player.method_64398(class_2561.method_43470("You were not in a group."));
        } else {
            player.method_64398(class_2561.method_43470("Left group: " + oldGroup.getName()));
            removeGroupIfEmpty(oldGroup.getId());
        }

        if (returnToMain) {
            showMainMenu(player);
        }
    }

    private void showGroupInfo(class_3222 player) {
        VoicechatConnection connection = getConnection(player);
        if (connection == null) {
            player.method_64398(class_2561.method_43470("Voice chat connection is unavailable."));
            return;
        }

        Group group = connection.getGroup();
        if (group == null) {
            player.method_64398(class_2561.method_43470("You are not currently in a voice chat group."));
            return;
        }

        player.method_64398(class_2561.method_43470(
                "Current group: " + group.getName() +
                        " | Type: " + groupTypeLabel(group.getType()) +
                        " | Locked: " + (group.hasPassword() ? "Yes" : "No") +
                        " | Persistent: " + (group.isPersistent() ? "Yes" : "No")
        ));
    }

    private void maybeRunDvcStart(class_3222 player) {
        Instant now = Instant.now();
        Instant last = dvcCooldown.get(player.method_5667());
        if (last != null && now.isBefore(last.plus(dvcStartCooldown))) {
            return;
        }

        dvcCooldown.put(player.method_5667(), now);
        scheduleLater(1L, () -> {
            class_3222 online = getOnlinePlayer(player.method_5667());
            if (online != null) {
                dispatchAsPlayer(online, "dvc start");
            }
        });
        scheduleLater(20L, () -> {
            class_3222 online = getOnlinePlayer(player.method_5667());
            if (online != null) {
                dispatchAsPlayer(online, "dvc start");
            }
        });
    }

    private void ensureDiscordVoiceStartedForGroupJoin(class_3222 player) {
        dvcCooldown.put(player.method_5667(), Instant.now());

        scheduleLater(10L, () -> {
            class_3222 online = getOnlinePlayer(player.method_5667());
            if (online != null) {
                dispatchAsPlayer(online, "dvc start");
            }
        });
        scheduleLater(40L, () -> {
            class_3222 online = getOnlinePlayer(player.method_5667());
            if (online != null) {
                dispatchAsPlayer(online, "dvc start");
            }
        });
    }

    private void handleBedrockVoicechatInvite(class_3222 inviter, class_3222 target) {
        VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
        if (voicechatServerApi == null) {
            inviter.method_64398(class_2561.method_43470("Voice chat API is not ready yet."));
            return;
        }

        if (Objects.equals(inviter.method_5667(), target.method_5667())) {
            inviter.method_64398(class_2561.method_43470("You cannot invite yourself."));
            return;
        }

        VoicechatConnection inviterConnection = getConnection(inviter);
        if (inviterConnection == null) {
            inviter.method_64398(class_2561.method_43470("Your voice chat connection is unavailable."));
            return;
        }

        Group group = inviterConnection.getGroup();
        if (group == null) {
            inviter.method_64398(class_2561.method_43470("You must be in a voice chat group to invite players."));
            return;
        }

        VoicechatConnection targetConnection = getConnection(target);
        if (targetConnection != null
                && targetConnection.getGroup() != null
                && Objects.equals(targetConnection.getGroup().getId(), group.getId())) {
            inviter.method_64398(class_2561.method_43470(target.method_5477().getString() + " is already in your voice chat group."));
            return;
        }

        pendingBedrockInvites.put(
                target.method_5667(),
                new BedrockGroupInvite(inviter.method_5667(), inviter.method_5477().getString(), group.getId(), Instant.now())
        );
        inviter.method_64398(class_2561.method_43470("Sent a voice chat invite to " + target.method_5477().getString() + "."));
        showBedrockInvitePopup(target, inviter.method_5477().getString(), group);
    }

    private void showBedrockInvitePopup(class_3222 target, String inviterName, Group group) {
        String groupDetails = "Group: " + group.getName() + "\n"
                + "Type: " + groupTypeLabel(group.getType()) + "\n"
                + "Locked: " + (group.hasPassword() ? "Yes" : "No");

        SimpleForm.Builder form = SimpleForm.builder()
                .title("Voice Chat Invite")
                .content(inviterName + " has invited you to join this voice chat group.\n\n" + groupDetails)
                .button("Accept")
                .button("Decline")
                .validResultHandler(response -> {
                    if (response.clickedButtonId() == 0) {
                        acceptBedrockInvite(target);
                    } else {
                        declineBedrockInvite(target, true);
                    }
                })
                .closedOrInvalidResultHandler(() -> declineBedrockInvite(target, false));

        sendToBedrock(target, form);
    }

    private void acceptBedrockInvite(class_3222 target) {
        BedrockGroupInvite invite = pendingBedrockInvites.remove(target.method_5667());
        if (invite == null) {
            target.method_64398(class_2561.method_43470("That voice chat invite is no longer available."));
            return;
        }
        if (invite.isExpired()) {
            target.method_64398(class_2561.method_43470("That voice chat invite expired."));
            return;
        }
        VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
        if (voicechatServerApi == null) {
            target.method_64398(class_2561.method_43470("Voice chat API is not ready yet."));
            return;
        }

        Group group = voicechatServerApi.getGroup(invite.groupId());
        if (group == null) {
            target.method_64398(class_2561.method_43470("That voice chat group is no longer available."));
            return;
        }

        joinGroup(target, group, null, true, false);
    }

    private void declineBedrockInvite(class_3222 target, boolean sendMessage) {
        BedrockGroupInvite removed = pendingBedrockInvites.remove(target.method_5667());
        if (sendMessage && removed != null) {
            target.method_64398(class_2561.method_43470("Declined the voice chat invite from " + removed.inviterName() + "."));
        }
    }

    private void sendDiscordVoiceReminder(class_3222 player) {
        player.method_64398(class_2561.method_43470("Join the Discord voice channel in your Discord app to talk."));
    }

    private void removeGroupIfEmpty(UUID groupId) {
        scheduleLater(20L, () -> {
            VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
            if (voicechatServerApi == null) {
                return;
            }

            Group group = voicechatServerApi.getGroup(groupId);
            if (group == null) {
                return;
            }
            if (isPersistentGroup(group, groupId)) {
                return;
            }

            boolean anyInGroup = false;
            if (server != null) {
                for (class_3222 online : server.method_3760().method_14571()) {
                    VoicechatConnection connection = getConnection(online);
                    if (connection != null && connection.getGroup() != null && Objects.equals(connection.getGroup().getId(), groupId)) {
                        anyInGroup = true;
                        break;
                    }
                }
            }

            if (!anyInGroup) {
                try {
                    voicechatServerApi.removeGroup(groupId);
                } catch (RuntimeException exception) {
                    LOGGER.debug("Skipping removal of stale voice chat group {}", groupId, exception);
                }
                groupPasswords.remove(groupId);
            }
        });
    }

    private boolean isPersistentGroup(Group group, UUID groupId) {
        try {
            return group.isPersistent();
        } catch (RuntimeException exception) {
            LOGGER.debug("Skipping stale voice chat group {} during cleanup", groupId, exception);
            return true;
        }
    }

    private void onPlayerQuit(class_3222 player) {
        UUID left = player.method_5667();
        cancelJoinMenuRefresh(left);
        menuStates.remove(left);
        joinMenuSignatures.remove(left);
        pendingBedrockInvites.remove(left);

        UUID groupId = lastKnownGroupByPlayer.remove(left);
        if (groupId != null) {
            removeGroupIfEmpty(groupId);
        }
    }

    private void syncBedrockState(class_3222 player) {
        if (!isBedrockPlayer(player)) {
            return;
        }
        if (usesNetherStarAccess()) {
            giveVcMenuItem(player);
        } else {
            removeVcMenuItems(player);
        }
    }

    private void scheduleJoinMenuRefresh(class_3222 player) {
        UUID uuid = player.method_5667();
        long token = ++nextTaskId;
        joinMenuRefreshTokens.put(uuid, token);
        scheduleJoinMenuRefresh(uuid, token);
    }

    private void scheduleJoinMenuRefresh(UUID uuid, long token) {
        scheduleLater(joinMenuRefreshTicks, () -> {
            if (!Objects.equals(joinMenuRefreshTokens.get(uuid), token)) {
                return;
            }
            if (menuStates.getOrDefault(uuid, MenuState.NONE) != MenuState.JOIN_GROUP) {
                cancelJoinMenuRefresh(uuid);
                return;
            }

            class_3222 player = getOnlinePlayer(uuid);
            if (player == null || !isBedrockPlayer(player)) {
                cancelJoinMenuRefresh(uuid);
                setMenuState(uuid, MenuState.NONE);
                return;
            }

            List<Group> groups = getSortedGroups();
            String currentSignature = createJoinMenuSignature(groups);
            String previousSignature = joinMenuSignatures.get(uuid);
            if (!Objects.equals(previousSignature, currentSignature)) {
                showJoinGroupMenu(player);
                return;
            }

            scheduleJoinMenuRefresh(uuid, token);
        });
    }

    private void cancelJoinMenuRefresh(UUID uuid) {
        joinMenuRefreshTokens.remove(uuid);
        joinMenuSignatures.remove(uuid);
    }

    private void dismissMenu(class_3222 player) {
        cancelJoinMenuRefresh(player.method_5667());
        setMenuState(player.method_5667(), MenuState.NONE);
    }

    private void setMenuState(UUID playerId, MenuState state) {
        if (state == MenuState.NONE) {
            menuStates.remove(playerId);
            joinMenuSignatures.remove(playerId);
            return;
        }
        menuStates.put(playerId, state);
        if (state != MenuState.JOIN_GROUP) {
            joinMenuSignatures.remove(playerId);
        }
    }

    private VoicechatConnection getConnection(class_3222 player) {
        VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
        if (voicechatServerApi == null) {
            return null;
        }
        return voicechatServerApi.getConnectionOf(player.method_5667());
    }

    private List<Group> getSortedGroups() {
        VoicechatServerApi voicechatServerApi = getVoicechatServerApi();
        if (voicechatServerApi == null) {
            return List.of();
        }

        Collection<Group> groups = voicechatServerApi.getGroups();
        List<Group> sortedGroups = new ArrayList<>(groups);
        sortedGroups.sort(
                Comparator.comparing(Group::getName, String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(group -> group.getId().toString())
        );
        return sortedGroups;
    }

    private String createJoinMenuSignature(List<Group> groups) {
        StringBuilder signature = new StringBuilder();
        for (Group group : groups) {
            signature.append(group.getId())
                    .append('|')
                    .append(group.getName())
                    .append('|')
                    .append(groupTypeLabel(group.getType()))
                    .append('|')
                    .append(group.hasPassword())
                    .append(';');
        }
        return signature.toString();
    }

    private String normalizePassword(String rawPassword) {
        if (rawPassword == null) {
            return null;
        }
        String trimmed = rawPassword.trim();
        if (trimmed.isEmpty() || trimmed.equalsIgnoreCase("null")) {
            return null;
        }
        return trimmed;
    }

    private String escapeQuotes(String input) {
        return input.replace("\"", "\\\"");
    }

    private boolean isBedrockPlayer(class_3222 player) {
        FloodgateApi floodgateApi = FloodgateApi.getInstance();
        return floodgateApi != null && floodgateApi.isFloodgatePlayer(player.method_5667());
    }

    private void dispatchAsPlayer(class_3222 player, String commandWithoutSlash) {
        if (server == null) {
            return;
        }
        server.method_3734().method_44252(player.method_64396(), commandWithoutSlash);
    }

    private boolean usesNetherStarAccess() {
        return menuAccessMode == MenuAccessMode.NETHER_STAR || menuAccessMode == MenuAccessMode.BOTH;
    }

    private String groupTypeLabel(Group.Type type) {
        return type == null ? "NORMAL" : String.valueOf(type).toUpperCase(Locale.ROOT);
    }

    private Group.Type resolveGroupType(String typeRaw) {
        if (typeRaw == null) {
            return Group.Type.NORMAL;
        }

        return switch (typeRaw.trim().toUpperCase(Locale.ROOT)) {
            case "OPEN" -> Group.Type.OPEN;
            case "ISOLATED" -> Group.Type.ISOLATED;
            default -> Group.Type.NORMAL;
        };
    }

    private void sendToBedrock(class_3222 player, FormBuilder<?, ?, ?> form) {
        if (form == null) {
            player.method_64398(class_2561.method_43470("An error occurred creating the form. Please try again."));
            return;
        }

        FloodgateApi floodgateApi = FloodgateApi.getInstance();
        if (floodgateApi == null) {
            player.method_64398(class_2561.method_43470("Floodgate API is unavailable."));
            return;
        }

        FloodgatePlayer floodgatePlayer = floodgateApi.getPlayer(player.method_5667());
        if (floodgatePlayer == null) {
            player.method_64398(class_2561.method_43470("You are not detected as Bedrock."));
            return;
        }

        floodgateApi.sendForm(player.method_5667(), form);
    }

    private class_3222 getOnlinePlayer(UUID uuid) {
        return server == null ? null : server.method_3760().method_14602(uuid);
    }

    private VoicechatServerApi getVoicechatServerApi() {
        return SHARED_VOICECHAT_SERVER_API;
    }

    private void giveVcMenuItem(class_3222 player) {
        moveProtectedSlotItemOutOfWay(player);
        if (hasVcMenuItem(player)) {
            return;
        }

        class_1799 menuItem = createVcMenuItem();
        class_1661 inventory = player.method_31548();
        if (inventory.method_5438(8).method_7960()) {
            inventory.method_5447(8, menuItem);
        } else {
            inventory.method_7394(menuItem);
        }
        player.field_7512.method_7623();
    }

    private void moveProtectedSlotItemOutOfWay(class_3222 player) {
        class_1661 inventory = player.method_31548();
        class_1799 protectedSlot = inventory.method_5438(8);
        if (protectedSlot.method_7960() || isVcMenuItem(protectedSlot)) {
            return;
        }

        int emptySlot = inventory.method_7376();
        if (emptySlot >= 0 && emptySlot != 8) {
            inventory.method_5447(emptySlot, protectedSlot.method_7972());
            inventory.method_5447(8, class_1799.field_8037);
            player.field_7512.method_7623();
        }
    }

    private boolean hasVcMenuItem(class_3222 player) {
        class_1661 inventory = player.method_31548();
        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            if (isVcMenuItem(inventory.method_5438(slot))) {
                return true;
            }
        }
        return false;
    }

    private void removeVcMenuItems(class_3222 player) {
        class_1661 inventory = player.method_31548();
        boolean changed = false;

        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            if (isVcMenuItem(inventory.method_5438(slot))) {
                inventory.method_5447(slot, class_1799.field_8037);
                changed = true;
            }
        }

        if (changed) {
            player.field_7512.method_7623();
        }
    }

    private void sanitizeMenuItemState(class_3222 player) {
        moveProtectedSlotItemOutOfWay(player);

        class_1661 inventory = player.method_31548();
        class_1703 menu = player.field_7512;

        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            if (slot == 8) {
                continue;
            }
            if (isVcMenuItem(inventory.method_5438(slot))) {
                inventory.method_5447(slot, class_1799.field_8037);
            }
        }

        for (class_1735 slot : menu.field_7761) {
            class_1799 slotItem = slot.method_7677();
            if (!isVcMenuItem(slotItem)) {
                continue;
            }
            class_1263 slotContainer = slot.field_7871;
            boolean isProtectedSlot = slotContainer == inventory && slot.method_34266() == 8;
            if (!isProtectedSlot) {
                slot.method_7673(class_1799.field_8037);
            }
        }

        if (!isVcMenuItem(inventory.method_5438(8))) {
            inventory.method_5447(8, createVcMenuItem());
        }
        player.field_7512.method_7623();
    }

    private class_1799 createVcMenuItem() {
        class_1799 item = new class_1799(class_1802.field_8137);
        item.method_57379(class_9334.field_49631, class_2561.method_43470("VC Menu"));
        class_2487 tag = new class_2487();
        tag.method_10556(VC_MENU_MARKER, true);
        item.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        return item;
    }

    private boolean isVcMenuItem(class_1799 item) {
        if (item == null || item.method_7960() || !item.method_31574(class_1802.field_8137)) {
            return false;
        }
        class_9279 customData = item.method_58694(class_9334.field_49628);
        if (customData == null) {
            return false;
        }
        return customData.method_57461().method_10577(VC_MENU_MARKER).orElse(false);
    }

    private void scheduleLater(long delayTicks, Runnable action) {
        long runAt = currentTick + Math.max(1L, delayTicks);
        synchronized (scheduledTasks) {
            scheduledTasks.add(new ScheduledTask(runAt, ++nextTaskId, action));
        }
    }

    private void runDueTasks() {
        List<ScheduledTask> due = new ArrayList<>();
        synchronized (scheduledTasks) {
            scheduledTasks.removeIf(task -> {
                if (task.runAtTick() <= currentTick) {
                    due.add(task);
                    return true;
                }
                return false;
            });
        }

        for (ScheduledTask task : due) {
            try {
                task.action().run();
            } catch (Exception exception) {
                LOGGER.error("Scheduled VoiceBridgeHelper task failed", exception);
            }
        }
    }

    private void loadConfig() {
        Path configPath = FabricLoader.getInstance().getConfigDir().resolve("voicebridgehelper.properties");
        Properties properties = new Properties();

        if (Files.notExists(configPath)) {
            properties.setProperty("discord-start-cooldown-seconds", "15");
            properties.setProperty("join-menu-refresh-ticks", "60");
            properties.setProperty("menu-access-mode", "COMMAND");
            try {
                Files.createDirectories(configPath.getParent());
                try (OutputStream outputStream = Files.newOutputStream(configPath)) {
                    properties.store(outputStream, "VoiceBridgeHelper Fabric config");
                }
            } catch (IOException exception) {
                LOGGER.warn("Failed to write default config", exception);
            }
        }

        try (InputStream inputStream = Files.newInputStream(configPath)) {
            properties.load(inputStream);
        } catch (IOException exception) {
            LOGGER.warn("Failed to read config, using defaults", exception);
        }

        dvcStartCooldown = Duration.ofSeconds(parseLong(properties.getProperty("discord-start-cooldown-seconds"), 15L));
        joinMenuRefreshTicks = Math.max(40L, parseLong(properties.getProperty("join-menu-refresh-ticks"), 60L));
        menuAccessMode = parseMenuAccessMode(properties.getProperty("menu-access-mode", "COMMAND"));
    }

    private long parseLong(String rawValue, long fallback) {
        if (rawValue == null) {
            return fallback;
        }
        try {
            return Long.parseLong(rawValue.trim());
        } catch (NumberFormatException exception) {
            return fallback;
        }
    }

    private MenuAccessMode parseMenuAccessMode(String rawMode) {
        if (rawMode == null) {
            return MenuAccessMode.COMMAND;
        }
        return switch (rawMode.trim().toUpperCase(Locale.ROOT)) {
            case "BOTH" -> MenuAccessMode.BOTH;
            case "NETHER_STAR" -> MenuAccessMode.NETHER_STAR;
            case "COMMAND" -> MenuAccessMode.COMMAND;
            default -> {
                LOGGER.warn("Invalid menu-access-mode '{}' in config. Falling back to COMMAND.", rawMode);
                yield MenuAccessMode.COMMAND;
            }
        };
    }
}
